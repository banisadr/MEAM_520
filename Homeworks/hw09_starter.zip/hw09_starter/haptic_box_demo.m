%% haptic_box_demo.m
%
% This script enables the user to touch a virtual box using a PHANToM
% Premium 1.0 haptic interface.  The user's position is shown as a small
% red circle, and the sides of the box are transparent.  The user is
% trapped inside the box, and each wall is rendered using a virtual spring.
% This script is provided to you in fully functional form so you can see
% and feel how haptic rendering works.
%
% Written by Katherine J. Kuchenbecker for MEAM 520 at the University of Pennsylvania.


%% Clean up

clear all
close all
clc


%% Set hardware mode, duration, and warnings

% Set whether to use the actual PHANToM hardware.  If this variable is set
% to false, the software will simulate the presence of a user by reading a
% pre-recorded trajectory.  You should use this mode to debug your code
% before running anything on the PHANToM computer.  Once you are on the
% PHANToM/PUMA computer in Towne B2, you may set this variable to true.  
% Always first run your code with the emergency stop down to prevent the
% application of forces and make sure everything works correctly on the real
% robot.  Hold onto the PHANToM tightly and keep a hand on the emergency stop.
hardware = false;

% Set how many times we want our servo loop to run.  Each cycle takes about
% two milliseconds on the computer in Towne B2.  There are 10000 cycles in
% the recorded data file.  If nCycles exceeds 10000, the motion loops.
nCycles = 2000;

% If not using the hardware, turn off warnings triggered when you command
% joint torques above the limits. 
if (~hardware)
    warning('off','PHANToM:JointTorque')
else
    warning('on','PHANToM:JointTorque')
end


%% Define the virtual environment

% Set the stiffness of the virtual walls in newtons per millimeter.
k = 0.1; % Keep this value positive and smaller than 0.5

% The location of the center of the box, relative to the origin of the
% Phantom's coordinate frame.  X is positive toward the user, Y is positive
% to the right, and Z is positive up. All dimensions are in millimeters.
boxCenterX = 190;
boxCenterY = 0;
boxCenterZ = 175;

% The width of the box in all three Cartesian directions.
boxWidthX = 60;
boxWidthY = 75;
boxWidthZ = 75;

% Calculate the locations of the six walls of the box based on the location
% of the center and the width of the box in all directions.

% The back and front walls are located at different X positions.
backWallX = boxCenterX - boxWidthX/2;
frontWallX = boxCenterX + boxWidthX/2;

% The left and right walls are located at different Y positions.
leftWallY = boxCenterY - boxWidthY/2;
rightWallY = boxCenterY + boxWidthY/2;

% The bottom and top walls are located at different Z positions.
bottomWallZ = boxCenterZ - boxWidthZ/2;
topWallZ = boxCenterZ + boxWidthZ/2;

% Set the colors of the three walls.
backFrontColor = [0 0 1]; % blue
leftRightColor = [1 0 0]; % red
topBottomColor = [1 1 0]; % yellow

% Set the alpha (transparency) of the box faces.
boxFaceAlpha = 0.3;

% Set the scale of the force vector in millimeters per newton.
fScale = 40;


%% Set up the figure for graphing

% Open figure 1.
figure(1);

% Plot a small red circle to represent the position of the PHANToM.  For
% now, we just put it at the origin.  We keep the handle to this plot
% (hPhantomDot) so that we can move the dot later.
hPhantomDot = plot3(0, 0, 0,'ro');

% Turn hold on to let us put more things on the graph.
hold on

% Plot a thick black line to represent the force vector.  For now, we just
% have it go from the origin to [10 10 10]; later we will set it to be a
% scaled version of the commanded force vector.  We keep the handle to this
% plot (hForceLine) so we can move the line later.
hForceLine = plot3([0 10], [0 10], [0 10],'k-','linewidth',2);

% Set the axis limits, the viewing direction, and other properties of
% the view.
axis equal vis3d
axis([0 300 -150 150 0 300]);
set(gca,'Xtick',0:50:300,'ytick',-150:50:150,'ztick',0:50:300)
view(100,16);
box on
grid on

% Label the axes.
xlabel('X (mm)')
ylabel('Y (mm)')
zlabel('Z (mm)')

% Add a title.
title('Haptic Box Demo')


%% Draw the walls of the box

% Plot each of the six walls in turn.
hbackwall = fill3(backWallX*[1 1 1 1], [leftWallY leftWallY rightWallY rightWallY], [bottomWallZ topWallZ topWallZ bottomWallZ], backFrontColor); set(hbackwall,'facealpha',boxFaceAlpha)
hfrontwall = fill3(frontWallX*[1 1 1 1], [leftWallY leftWallY rightWallY rightWallY], [bottomWallZ topWallZ topWallZ bottomWallZ], backFrontColor); set(hfrontwall,'facealpha',boxFaceAlpha)
hleftwall = fill3([backWallX backWallX frontWallX frontWallX], [leftWallY leftWallY leftWallY leftWallY], [bottomWallZ topWallZ topWallZ bottomWallZ], leftRightColor); set(hleftwall,'facealpha',boxFaceAlpha)
hrightwall = fill3([backWallX backWallX frontWallX frontWallX], [rightWallY rightWallY rightWallY rightWallY], [bottomWallZ topWallZ topWallZ bottomWallZ], leftRightColor); set(hrightwall,'facealpha',boxFaceAlpha)
htopwall = fill3([backWallX backWallX frontWallX frontWallX], [leftWallY rightWallY rightWallY leftWallY], [topWallZ topWallZ topWallZ topWallZ], topBottomColor); set(htopwall,'facealpha',boxFaceAlpha)
hbottomwall = fill3([backWallX backWallX frontWallX frontWallX], [leftWallY rightWallY rightWallY leftWallY], [bottomWallZ bottomWallZ bottomWallZ bottomWallZ], topBottomColor); set(hbottomwall,'facealpha',boxFaceAlpha)

% Turn hold off to stop allowing more graphing.
hold off;


%% Define the PHANToM parameters

% Link lengths in millimeters.
l1 = 168;
l2 = 140;
l3 = 140;


%% Do final preparations

% Start the Phantom, passing in hardware (true or false)
phantomStart(hardware);

% Initialize a vector to hold the time stamp for each cycle.
t = zeros(nCycles,1);

% Initialize vectors to store tip position and force output for each cycle.
hx_history = zeros(nCycles,1);
hy_history = zeros(nCycles,1);
hz_history = zeros(nCycles,1);
Fx_history = zeros(nCycles,1);
Fy_history = zeros(nCycles,1);
Fz_history = zeros(nCycles,1);

% Initialize a variable to hold the last time the graphics update was run.
lastGraphicsTime = 0;

% Call tic to latch the time.
tic;


%% Run the servo loop
for i = 1:nCycles
    % Measure the time and store it in our vector of time stamps.  
    % The units are seconds.
    t(i) = toc;
    
    % Get the Phantom's joint angles in radians.
    theta123 = phantomJointAngles;
    
    % Pull the three joint angles out of the vector.
    theta1 = theta123(1);
    theta2 = theta123(2);
    theta3 = theta123(3);
    
    % Calculate the position of the haptic device's tip using forward kinematics.
    % We store the result in hx, hy, and hz.  The units are millimeters.
    r = l2*cos(theta2) - l3*sin(theta3);
    hx = r*cos(theta1);
    hy = -r*sin(theta1);
    hz = l1 - l2*sin(theta2) - l3*cos(theta3);
    
    % Check the haptic device's x-position against the locations of the
    % back and front walls.
    if (hx < backWallX)
        % They are touching the back wall.  Calculate the haptic feedback
        % force to be proportional to and in the opposite direction as
        % their penetration into the wall.  The stiffness k is in newtons
        % per millimeter, and the positions are in millimeters, so the
        % resulting force is in newtons.
        Fx = k * (backWallX - hx);
    elseif (hx > frontWallX)
        % They are touching the front wall.  Calculate force.
        Fx = k * (frontWallX - hx);
    else
        % They are not touching the back or front wall; force is zero in
        % the x-direction.
        Fx = 0;
    end
    
    % Check the haptic device's y-position against the locations of the
    % left and right walls.
    if (hy < leftWallY)
        % They are touching the left wall.  Calculate force.
        Fy = k * (leftWallY - hy);
    elseif (hy > rightWallY)
        % They are touching the right wall.  Calculate force.
        Fy = k * (rightWallY - hy);
    else
        % They are not touching the left or right wall; force is zero in
        % the y-direction.
        Fy = 0;
    end
    
    % Check the haptic device's z-position against the locations of the
    % bottom and top walls.
    if (hz < bottomWallZ)
        % They are touching the bottom wall.  Calculate force.
        Fz = k * (bottomWallZ - hz);
    elseif (hz > topWallZ)
        % They are touching the top wall.  Calculate force.
        Fz = k * (topWallZ - hz);
    else
        % They are not touching the bottom or top wall; force is zero in
        % the z-direction.
        Fz = 0;
    end

    % Calculate the linear velocity Jacobian for the PHANToM at the present
    % joint angles. This formula was derived by calculating the partial
    % derivatives of the x, y, and z tip position equations.
    Jv = [-sin(theta1)*(l2*cos(theta2)-l3*sin(theta3)) -l2*cos(theta1)*sin(theta2)  -l3*cos(theta1)*cos(theta3);
          -cos(theta1)*(l2*cos(theta2)-l3*sin(theta3))  l2*sin(theta1)*sin(theta2)   l3*sin(theta1)*cos(theta3);
                                                     0             -l2*cos(theta2)               l3*sin(theta3)];
                                                  
    % Calculate the three joint torques by multiplying the desired force
    % vector by the transpose of the Jacobian and dividing by 1000 (to
    % convert from millimeters to meters).  Units are newton-meters.
    tau123 = Jv' * [Fx Fy Fz]' / 1000;
    
    % Command the necessary joint torques.
    phantomJointTorques(tau123(1), tau123(2), tau123(3));
    
    % Store this cycle's values in the history vectors.
    hx_history(i) = hx;
    hy_history(i) = hy;
    hz_history(i) = hz;
    Fx_history(i) = Fx;
    Fy_history(i) = Fy;
    Fz_history(i) = Fz;

    % Check how much time has elapsed since we last updated the graphics.
    if (t(i) - lastGraphicsTime > 0.03)
        % Enough time has passed.
        
        % Update the graph by setting the data for the PHANToM's dot to the
        % position of the haptic device.
        set(hPhantomDot, 'xdata', hx, 'ydata', hy, 'zdata', hz)

        % Update the graph by setting the data for the force line to show a
        % scaled version of the commanded force.
        set(hForceLine,'xdata',[hx hx+Fx*fScale],'ydata',[hy hy+Fy*fScale], 'zdata',[hz hz+Fz*fScale]);

        % Store this time for future comparisons.
        lastGraphicsTime = t(i);
    end
    
    % Pause for one millisecond to keep things moving at a reasonable pace.
    pause(.001);
end

% Stop the Phantom.
phantomStop;


%% Plot the results

% Open figure 2 and clear it.
figure(2)
clf

% Plot positions over time in the top subplot.
subplot(2,1,1)
h = plot(t,[hx_history hy_history hz_history]);
set(h(1),'color',[0 .7 .7])
set(h(2),'color',[.7 .7 0])
set(h(3),'color',[.7 0 .7])
xlabel('Time (s)')
ylabel('Tip Position (mm)')
legend('h_x', 'h_y', 'h_z')

% Plot forces over time in the bottom subplot.
subplot(2,1,2)
h = plot(t,[Fx_history Fy_history Fz_history]);
set(h(1),'color',[0 .7 .7])
set(h(2),'color',[.7 .7 0])
set(h(3),'color',[.7 0 .7])
xlabel('Time (s)')
ylabel('Force (N)')
legend('F_x', 'F_y', 'F_z')
