function [tau1, tau2, tau3] = phantom_force_to_torques_starter(Fx, Fy, Fz, theta1, theta2, theta3)

% The inputs are the desired Cartesian force vector in N and the robot's
% present pose, specified as joint angles in radians.
% The outputs are joint torques in Nm.

% For now, just return all zeros.
tau1 = 0;
tau2 = 0;
tau3 = 0;