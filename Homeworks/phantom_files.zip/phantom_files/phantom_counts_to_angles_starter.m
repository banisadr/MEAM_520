function [theta1, theta2, theta3] = phantom_counts_to_angles_starter(Q1, Q2, Q3)

% The inputs are encoder values in counts.
% The outputs are joint angles in radians.

% For now, just return all zeros.
theta1 = 0;
theta2 = 0;
theta3 = 0;