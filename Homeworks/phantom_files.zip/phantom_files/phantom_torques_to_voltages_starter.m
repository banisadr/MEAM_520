function [V1, V2, V3] = phantom_torques_to_voltages_starter(tau1, tau2, tau3)

% The inputs are joint torques in Nm.
% The outputs are DAC voltages in V.

% For now, just return all zeros.
V1 = 0;
V2 = 0;
V3 = 0;