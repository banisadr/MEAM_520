function Xdot = compute_motor_derivatives_starter(t,X)


% Define parameters of the Maxon 118743 motor.
kt = 23.467E-3; % N m/A, derived from data sheet.
% Add other motor parameters here, noting their units and their source.


% Pull states out of state vector.
thetam = X(1); % Motor angle in radians.
omegam = X(2); % Motor angular velocity in radians per second.
ia = X(3); % Armature current in amps.


% Declare global variables so we can access their values.
global Vperiod Vpulse

% Calculate the voltage input at this instant in time.
% V is the voltage you should apply to the motor.
if (mod(t,Vperiod) > (Vperiod/2))
    V = Vpulse;
else
    V = 0;
end


% Set the test type.
testtype = 0; % Type of test to run.  0 is no load.  1 is stall.


% Check the test type.
if testtype
    % Stall test.  Set the load torque to be a torsional spring and damper,
    % as specified in the assignment.
    %taul = ...
else
    % No-load test.  Set the load torque to be zero.
    taul = 0;
end


% Calculate the derivative of each of our states, based on the input
% voltage, the motor's present state, and the motors electro-mechanical
% dynamics.

% For now we set all derivatives equal to zero.  You must change this.
thetamdot = 0;
omegamdot = 0;
iadot = 0;


% Create state derivative vector.
Xdot = [thetamdot ; omegamdot ; iadot];