function [p1, p2, p3, p4] = phantom_angles_to_positions_starter(theta1, theta2, theta3)

% The inputs are joint angles in radians.
% The outputs are the xyz positions of points along the robot for plotting.  
% Each point should be a three-element column vector.  The last one you
% return should be the tip position. 

% For now, just plot static points in the approximate shape of the Phantom.
p1 = [0 0 0]';
p2 = [0 0 150]';
p3 = [150 0 150]';
p4 = [150 0 50]';
