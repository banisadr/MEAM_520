%% Clear the workspace.
clear


%% Define the problem.

% Define initial and final times.
t0 = 0; % s
tf = 2; % s

% Define initial conditions.
q0 = -2.6;  % radians
v0 = 0;     % rad/s
alpha0 = 0; % rad/s^2

% Define final conditions.
qf = 1.3;   % radians
vf = 0;     % rad/s
alphaf = 0; % rad/s^2


%% Solve for the quintic polynomial coefficients that meet these conditions.

% Put initial and final conditions into a column vector.
conditions = [q0 v0 alpha0 qf vf alphaf]';

% Put time elements into matrix.
mat = [1    t0   t0^2     t0^3    t0^4    t0^5; 
       0     1   2*t0   3*t0^2  4*t0^3  5*t0^4; 
       0     0      2     6*t0 12*t0^2 20*t0^3;
       1    tf   tf^2     tf^3    tf^4    tf^5; 
       0     1   2*tf   3*tf^2  4*tf^3  5*tf^4;
       0     0      2     6*tf 12*tf^2 20*tf^3];

% Solve for coefficients.
coeffs = mat \ conditions;

% Pull individual coefficients out.
a0 = coeffs(1);
a1 = coeffs(2);
a2 = coeffs(3);
a3 = coeffs(4);
a4 = coeffs(5);
a5 = coeffs(6);


%% Plot the quintic polynomial we calculated.

% Create time vector.
tstep = 0.01;
t = (t0:tstep:tf)';

% Calculate quintic trajectory with coefficients.
q = a0 + a1*t + a2*t.^2 + a3*t.^3 + a4*t.^4 + a5*t.^5;

% Open figure 3.
figure(3)
clf

% Plot quintic trajectory.
set(gca,'fontsize',14)
plot(t,q,'b')
xlabel('Time (s)')
ylabel('q (radians)')
title('Quintic Polynomial')


%% Plot the quintic polynomial and its derivatives in another figure.

showDerivativesPlot = true;
if (showDerivativesPlot)
    
    % Open figure 4.
    figure(4)
    clf
    
    % Plot quintic trajectory in first subplot.
    subplot(3,1,1)
    set(gca,'fontsize',14)
    plot(t,q,'b')
    xlabel('Time (s)')
    ylabel('q (radians)')
    title('Quintic Polynomial')
    
    % Calculate first time-derivative of quintic trajectory with coefficients.
    qdot = a1 + 2*a2*t + 3*a3*t.^2 + 4*a4*t.^3 + 5*a5*t.^4;
    
    % Plot time derivative of quintic trajectory in second subplot.
    subplot(3,1,2)
    set(gca,'fontsize',14)
    plot(t,qdot,'m')
    xlabel('Time (s)')
    ylabel('v (radians/s)')
    
    % Calculate second time-derivative of cubic trajectory with coefficients.
    qdoubledot = 2*a2 + 6*a3*t + 12*a4*t.^2 + 20*a5*t.^3;
    
    % Plot second time derivative of cubic trajectory in third subplot.
    subplot(3,1,3)
    set(gca,'fontsize',14)
    plot(t,qdoubledot,'r')
    xlabel('Time (s)')
    ylabel('alpha (radians/s^2)')

end