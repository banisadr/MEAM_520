%% Clear the workspace.
clear


%% Define the problem.

% Define initial and final times.
t0 = 0; % s
tf = 2; % s

% Define initial conditions.
q0 = -2.6; % radians
v0 = 0;    % rad/s

% Define final conditions.
qf = 1.3;  % radians
vf = 1;    % rad/s


%% Solve for the cubic polynomial coefficients that meet these conditions.

% Put initial and final conditions into a column vector.
conditions = [q0 v0 qf vf]';

% Put time elements into matrix.
mat = [1    t0   t0^2     t0^3; 
       0     1   2*t0   3*t0^2; 
       1    tf   tf^2     tf^3; 
       0     1   2*tf   3*tf^2];

% Solve for coefficients.
coeffs = mat \ conditions;

% Pull individual coefficients out.
a0 = coeffs(1);
a1 = coeffs(2);
a2 = coeffs(3);
a3 = coeffs(4);


%% Plot the cubic polynomial we calculated.

% Create time vector.
tstep = 0.01;
t = (t0:tstep:tf)';

% Calculate cubic trajectory with coefficients.
q = a0 + a1*t + a2*t.^2 + a3*t.^3;

% Open figure 1.
figure(1)
clf

% Plot cubic trajectory.
set(gca,'fontsize',14)
plot(t,q,'b')
xlabel('Time (s)')
ylabel('q (radians)')
title('Two Cubic Polynomials')


%% Plot the cubic polynomial and its derivatives in another figure.

showDerivativesPlot = true;
if (showDerivativesPlot)
    
    % Open figure 2.
    figure(2)
    clf
    
    % Plot cubic trajectory in first subplot.
    subplot(3,1,1)
    set(gca,'fontsize',14)
    plot(t,q,'b')
    xlabel('Time (s)')
    ylabel('q (radians)')
    title('Two Cubic Polynomials')
    
    % Calculate first time-derivative of cubic trajectory with coefficients.
    qdot = a1 + 2*a2*t + 3*a3*t.^2;
    
    % Plot time derivative of cubic trajectory in second subplot.
    subplot(3,1,2)
    set(gca,'fontsize',14)
    plot(t,qdot,'m')
    xlabel('Time (s)')
    ylabel('v (radians/s)')
    
    % Calculate second time-derivative of cubic trajectory with coefficients.
    qdoubledot = 2*a2 + 6*a3*t;
    
    % Plot second time derivative of cubic trajectory in third subplot.
    subplot(3,1,3)
    set(gca,'fontsize',14)
    plot(t,qdoubledot,'r')
    xlabel('Time (s)')
    ylabel('a (radians/s^2)')

end

%% Define the second problem.

% Define initial and final times.
t0 = tf; % s
tf = 5; % s

% Define initial conditions.
q0 = qf; % radians
v0 = vf;    % rad/s

% Define final conditions.
qf = -2.3;  % radians
vf = -.5;    % rad/s


%% Solve for the cubic polynomial coefficients that meet these conditions.

% Put initial and final conditions into a column vector.
conditions = [q0 v0 qf vf]';

% Put time elements into matrix.
mat = [1    t0   t0^2     t0^3; 
       0     1   2*t0   3*t0^2; 
       1    tf   tf^2     tf^3; 
       0     1   2*tf   3*tf^2];

% Solve for coefficients.
coeffs = mat \ conditions;

% Pull individual coefficients out.
a0 = coeffs(1);
a1 = coeffs(2);
a2 = coeffs(3);
a3 = coeffs(4);


%% Plot the cubic polynomial we calculated.

% Create time vector.
t = (t0:tstep:tf)';

% Calculate cubic trajectory with coefficients.
q = a0 + a1*t + a2*t.^2 + a3*t.^3;

% Open figure 1.
figure(1)
hold on;

% Plot cubic trajectory.
plot(t,q,'g')


%% Plot the cubic polynomial and its derivatives in another figure.

if (showDerivativesPlot)
    
    % Open figure 2.
    figure(2)
    
    % Plot cubic trajectory in first subplot.
    subplot(3,1,1)
    hold on
    plot(t,q,'g')
    
    % Calculate first time-derivative of cubic trajectory with coefficients.
    qdot = a1 + 2*a2*t + 3*a3*t.^2;
    
    % Plot time derivative of cubic trajectory in second subplot.
    subplot(3,1,2)
    hold on
    plot(t,qdot,'c')
    
    % Calculate second time-derivative of cubic trajectory with coefficients.
    qdoubledot = 2*a2 + 6*a3*t;
    
    % Plot second time derivative of cubic trajectory in third subplot.
    subplot(3,1,3)
    hold on
    plot(t,qdoubledot,'y')

end