%% Clear the workspace.
clear

show = [1 1 1];
showLabels = true;
showPlot = true;




%% Define the problem.

% Define initial conditions.
t0 = 0;     % s
q0 = -2.5;  % radians
v0 = 0;     % rad/s
alpha0 = 0; % rad/s^2

% Define final conditions.
tf = 2;     % s
qf = 1.9;   % radians
vf = 0;     % rad/s
alphaf = 0; % rad/s^2

















%% Solve for linear (first-order) polynomial coefficients that meet these conditions.

conditions = [q0 qf]';

% Put time elements into matrix.
mat = [1    t0; 
       1    tf];

% Solve for coefficients.
coeffs = mat \ conditions;

% Pull individual coefficients out.
a0l = coeffs(1);
a1l = coeffs(2);


%% Solve for the cubic (third-order) polynomial coefficients that meet these conditions.

% Put initial and final conditions into a column vector.
conditions = [q0 v0 qf vf]';

% Put time elements into matrix.
mat = [1    t0   t0^2     t0^3; 
       0     1   2*t0   3*t0^2; 
       1    tf   tf^2     tf^3; 
       0     1   2*tf   3*tf^2];

% Solve for coefficients.
coeffs = mat \ conditions;

% Pull individual coefficients out.
a0c = coeffs(1);
a1c = coeffs(2);
a2c = coeffs(3);
a3c = coeffs(4);


%% Solve for the quintic polynomial coefficients that meet these conditions.

% Put initial and final conditions into a column vector.
conditions = [q0 v0 alpha0 qf vf alphaf]';

% Put time elements into matrix.
mat = [1    t0   t0^2     t0^3    t0^4    t0^5; 
       0     1   2*t0   3*t0^2  4*t0^3  5*t0^4; 
       0     0      2     6*t0 12*t0^2 20*t0^3;
       1    tf   tf^2     tf^3    tf^4    tf^5; 
       0     1   2*tf   3*tf^2  4*tf^3  5*tf^4;
       0     0      2     6*tf 12*tf^2 20*tf^3];

% Solve for coefficients.
coeffs = mat \ conditions;

% Pull individual coefficients out.
a0q = coeffs(1);
a1q = coeffs(2);
a2q = coeffs(3);
a3q = coeffs(4);
a4q = coeffs(5);
a5q = coeffs(6);


%% Plot the trajectories we calculated.

% Create time vector.
tstep = 0.01;
t = (t0:tstep:tf)';

% Calculate linear trajectory with coefficients.
ql = a0l + a1l*t;

% Calculate cubic trajectory with coefficients.
qc = a0c + a1c*t + a2c*t.^2 + a3c*t.^3;

% Calculate quintic trajectory with coefficients.
qq = a0q + a1q*t + a2q*t.^2 + a3q*t.^3 + a4q*t.^4 + a5q*t.^5;
    
if (showPlot)
    
    % Open figure 2.
    figure(2)
    clf
    
    % Plot cubic trajectory.
    set(gca,'fontsize',14)
    plot(t,ql,'r',t,qc,'m', t, qq, 'b')
    xlabel('Time (s)')
    ylabel('q (radians)')
    legend('Line', 'Cubic Polynomial', 'Quintic Polynomial','Location', 'Best')

end


%% Animate three boxes over time.

figure(1)
clf
set(gca,'fontsize',14)
box on
hold on

plot([-2 2],[q0 q0],'k-.')
plot([-2 2],[qf qf],'k:')
axis([-2 2 q0-1 qf+1])


if show(1)
    b1 = plot(-1,q0,'rs','markersize',30,'markerfacecolor','r');
    if (showLabels)
        text(-1, qf+.5,'Linear','color','r','horizontalalignment','center','fontsize',14)
    end
else
    b1 = plot(-10,q0,'rs','markersize',30,'markerfacecolor','r');
end

if show(2)
    b2 = plot(0,q0,'ms','markersize',30,'markerfacecolor','m');
    if (showLabels)
        text(0, qf+.5,'Cubic','color','m','horizontalalignment','center','fontsize',14)
    end
else
    b2 = plot(-10,q0,'ms','markersize',30,'markerfacecolor','m');
end

if show(3)
    b3 = plot(1,q0,'bs','markersize',30,'markerfacecolor','b');
    if (showLabels)
        text(1, qf+.5,'Quintic','color','b','horizontalalignment','center','fontsize',14)
    end
else
    b3 = plot(-10,q0,'bs','markersize',30,'markerfacecolor','b');
end
hold off

b = [b1 ; b2 ; b3];
    
for i = 1:length(t)
    set(b(1),'ydata',ql(i))
    set(b(2),'ydata',qc(i))
    set(b(3),'ydata',qq(i))
    drawnow
end
