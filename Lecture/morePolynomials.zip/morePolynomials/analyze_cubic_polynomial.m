%% Clear the workspace.
clear


%% Define the variables as symbols that represent real numbers.
syms t0 tf q0 qf v0 vf real


%% Solve for the cubic polynomial coefficients that meet these conditions.

% Put initial and final conditions into a column vector.
conditions = [q0 v0 qf vf]'

% Put time elements into matrix.
mat = [1    t0   t0^2     t0^3; 
       0     1   2*t0   3*t0^2; 
       1    tf   tf^2     tf^3; 
       0     1   2*tf   3*tf^2]

% Solve for coefficients.
coeffs = mat \ conditions

% Pull individual coefficients out.
a0 = coeffs(1);
a1 = coeffs(2);
a2 = coeffs(3);
a3 = coeffs(4);


%% Figure out when there is a solution.

% There is no solution when the determinant of the matrix equals zero.

% Calculate determinant of matrix.
detmat = det(mat)

detmat = simplify(detmat)

pretty(detmat)