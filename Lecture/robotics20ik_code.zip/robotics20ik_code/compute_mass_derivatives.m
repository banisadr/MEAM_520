function Xdot = compute_mass_derivatives(t,X)

% Declare global variables so we can access their values.
global m k g

% Pull states out of state vector.
y = X(1);
vy = X(2);

% Say hello.
%disp('hello!')

% Calculate acceleration in m/s^2.  This came from our FBD and NSL.
ay = -g - k * y / m;

% Constant acceleration.
%ay = 1;

% Add an upward force after 2 seconds.
%if (t > 2)
%    ay = ay + 50;
%end

% Here is an example for how to make the force depend on time.  Note the
% use of && as logical and to combine conditions.

% Add an upward force after 2 seconds, only when y is positive.
%if ((t > 2) && (y > 0))
%    ay = ay + 50;
%end

% Will this work?
%if ((-0.2 < y) && (y < 0.2))
%    ay = 1;
%else
%    ay = 0;
%end

% Create state derivative vector.
Xdot = [vy ; ay];
