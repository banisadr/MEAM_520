%% Simulate a mass bouncing on a spring using ode45
% Class example for MEAM 520 on November 12, 2013 by KJK.

close all
clear;

%% Parameters
% Set parameters of the system we want to simulate, noting units.
% Make them global so that the compute derivatives function can see them.
global m k g
m = 3.5; % kg
k = 400; % N/m
g = 9.81; % m/s^2

%% Time
% Define the simulation's start time, end time, and maximum time step.
tstart = 0;
tfinal = 5;
tstepmax = 0.01; % Maximum time step, in seconds.

% Set the time step for the graphical display to control playback speed.
graphical_tstep = 0.01; % s

%% Initial Conditions
% Define the initial conditions for the mass.
y0 = .25; % m
v0 = 0; % m/s

% Put initial conditions into vector.
X0 = [y0; v0];

%% Simulation
% Show a message to explain how to cancel the graph.
disp('Click in this window and press control-c to cancel simulation or graphing if it is taking too long.')

% Run the simulation using ode45.
% The state equation function must be in the same directory as this script
% for Matlab to find it.  The @ makes the name a function handle, so ode45
% can call it over and over.  The other two inputs are the time span and
% the initial condition5s.  The outputs are the resulting time vector (nx1)
% and the resulting state vector (nx4).
% Here, we set the maximum time step to be tstep, to lower the likelihood
% that the solver will accidentally miss interactions with the interesting
% zones in the world.
[t, Xhistory] = ode45(@compute_mass_derivatives, [tstart tfinal], X0, odeset('MaxStep',tstepmax));

%% Plot set up

% The simulation results are not evenly spaced in time, so graphing them
% directly does not let you see the speed of the puck.  Thus, we
% re-interpolate the data to see where the puck is at evenly spaced moments
% in time.  This is the data we will plot below.
tplot = (tstart:graphical_tstep:tfinal)'; % New, evenly spaced time vector.

y = Xhistory(:,1); % Vertical position in meters.
v = Xhistory(:,2); % Vertical velocity in meters per second.
yplot = interp1(t,y,tplot); % Reinterpolated horizontal position.
vplot = interp1(t,v,tplot); % Reinterpolated vertical position.


%% Graphing
% Plot the position and velocity over time in figure 1.
figure(1)
subplot(2,1,1)
plot(t,y,'r-')
xlabel('Time (s)')
ylabel('Position (m)')

subplot(2,1,2)
plot(t,v,'b-')
xlabel('Time (s)')
ylabel('Velocity (m/s)')


%% Animation
% Animate the motion in figure 2.
figure(2);

% Plot the mass as a red square at the starting position, with an x
% coordinate of zero.  Keep a handle to this plot so we can modify it below
% in the animation loop.  Include a gray line up to [0 2] to represent 
% the spring.
h = plot([0 0],[yplot(1) 2],'s-','MarkerSize',70,'color',[.4 .4 .4],'markerfacecolor',[.7 .0 0]);

% Set the viewing widto to be -1 m to 1 m in both directions, with the axes
% being sized equally so motion is not distorted.
axis([-1 1 -1 1])
axis equal

% Step through the results of the simulation.
for i = 2:1:(length(tplot)-1)

    % Set the y-value of the plot to the next value in the simulation.
    % This moves the object to the next location.
    set(h,'ydata', [yplot(i) 2])

    % Pause for a short while to let the user see the graph.
    pause(0.001);

end