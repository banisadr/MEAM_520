%% scara_robot_circle_with_wrist_kuchenbe_v1.m
% 
% This Matlab demonstrates inverse orientation kinematics with a SCARA 
% robot with a spherical wrist.  This was shown in MEAM 520 lecture on
% November 21, 2013.

%% SETUP

% Clear all variables from the workspace.
clear all

% Clear the console, so you can more easily find any errors that may occur.
clc

% Define our time vector.
tStart = 0;   % The time at which the simulation starts, in seconds.
tStep = 0.04; % The simulation's time step, in seconds.
tEnd = 2*pi;    % The time at which the simulation ends, in seconds.
t = (tStart:tStep:tEnd)';  % The time vector (a column vector).

% Set whether to animate the robot's movement and how much to slow it down.
pause on;  % Set this to off if you don't want to watch the animation.
GraphingTimeDelay = 0.001; % The length of time that Matlab should pause between positions when graphing, if at all, in seconds.


%% ROBOT PARAMETERS

% This problem is about the first three joints (RRP) of a SCARA
% manipulator.  This robot's forward kinematics are worked out on pages 91
% to 93 of the SHV textbook, though we are ignoring the fourth joint (the
% wrist).

% Define robot link lengths.
a1 = 1.0; % Distance between joints 1 and 2, in meters.
a2 = 0.7; % Distance between joints 2 and 3, in meters.
d6 = a1/4; % Offset from wrist center to end-effector, in meters.


%% DEFINE CIRCULAR MOTION

% We want the SCARA to draw a vertical circle parallel to the x-z plane.

% Define the radius of the circle.
radius = .4; % meters

% Define the y-value for the plane that contains the circle.
y_offset = -1; % meters

% Define the x and z coordinates for the center of the circle.
x_center = -.5; % meters
z_center = -1.2; % meters

% Set the desired x, y, and z positions over time given the circle parameters.
ox_history = x_center + radius * sin(t);
oy_history = y_offset * ones(size(t));
oz_history = z_center + radius * cos(t);


%% SIMULATION

% Notify the user that we're starting the animation.
disp('Starting the animation.')

% Show a message to explain how to cancel the simulation and graphing.
disp('Click in this window and press control-c to stop the code.')

% Initialize a matrix to hold the position of the robot's tip over time.
% The first row is the x-coordinate, second is y, and third is z, all in
% the base frame.  You are welcome to make this 4 rows if you want to use
% the homogeneous representation for points.  It has the same number of
% columns as t has rows, one tip position for every time step in the
% simulation.  We keep track of this history so we can trace out the
% trajectory of where the robot's tip has been.
tip_history = zeros(3,length(t));

% Step through the time vector to animate the robot.
for i = 1:length(t)
    
    % Pull the current values of ox, oy, and oz from their histories. 
    ox = ox_history(i);
    oy = oy_history(i);
    oz = oz_history(i);
    
    % Calculate theta1, theta2, and d3 given the robot's parameters (a1 and
    % a2) and the current desired position for its tip ([ox oy oz]').

    % Calculate the cosine of theta2 using law of cosines.
    c2 = (ox.^2 + oy.^2 - a1^2 - a2^2)/(2*a1*a2);
    
    % Calculate the positive and negative solutions for theta2.
    theta2_pos = atan2(sqrt(1-c2^2),c2); % Corrected solution from our derivation.
    theta2_neg = atan2(-sqrt(1-c2^2),c2); % Corrected solution from our derivation.

    % Arbitrarily choose the positive solution.
    theta2 = theta2_pos;
    
    % Uncomment this line to choose the negative solution instead.
    %theta2 = theta2_neg;

    % Calculate theta1 using a pair of inverse tangents.  Note that MATLAB
    % atan2 takes the numerator and then the denominator.
    theta1 = atan2(oy,ox) - atan2(a2*sin(theta2),a1+a2*cos(theta2));

    % Calculate d3.
    d3 = -oz - d6; % Corrected solution from our derivation, with offset for wrist.

    % Use provided .p function to calculate the points of the robot that we
    % should plot to show in the animation.
    [points_to_plot, x06, y06, z06] = scara_robot_with_wrist_fk(a1, a2, d6, ...
        theta1, theta2, d3, 0, 0, 0); % <-- Try setting theta5 to pi/2 or -pi/2.
    
    % Grab the final plotted point for the trajectory graph.
    tip_history(:,i) = points_to_plot(1:3,end);

    % Check if this is the first time we are plotting.
    if (i == 1)
        % Open figure 1.
        figure(1);
        
        % The first time, plot the robot points and keep a handle to the plot.
        % This is a 3D plot with dots at the points and lines connecting
        % neighboring points, made thicker, with big dots, in dark gray.
        hrobot = plot3(points_to_plot(1,:),points_to_plot(2,:),points_to_plot(3,:), ...
            '.-','linewidth',5,'markersize',20,'color',[.3 .3 .3]);
        
        % Also plot the tip position of the robot, using hold on and hold
        % off, also keeping a handle to the plot so we can update the data
        % points later.
        hold on;
        htip = plot3(tip_history(1,i),tip_history(2,i),tip_history(3,i),'r.','markersize',15);
        hold off;

        % Label the axes.
        xlabel('X (m)');
        ylabel('Y (m)');
        zlabel('Z (m)');

        % Turn on the grid and the box.
        grid on;
        box on;

        % Set the axis properties for 3D visualization, which enables
        % rotation, and make one unit the same in every direction.
        axis equal vis3d

        % Set the axis limits.
        axis([-2 2 -2 2 -2 2])

        % Put text on the plot to show how much time has elapsed.  The text
        % is centered.
        htime = text(1,1,1,sprintf('t = %.2f s',t(i)),'horizontalAlignment','center');

        % Add a title including the student's name.
        title('SCARA Robot With a Spherical Wrist Drawing a Circle. Turn on the end-effector frame.');
        
        % Set whether to draw the coordinate frame at the end-effector.
        showEndEffectorFrame = true;
        
        % Plot the x, y, and z axes of frame 6.
        if showEndEffectorFrame
            hold on
            hx = plot3(x06(1,:), x06(2,:), x06(3,:), 'k:', 'linewidth',2);
            hy = plot3(y06(1,:), y06(2,:), y06(3,:), 'k--', 'linewidth',2);
            hz = plot3(z06(1,:), z06(2,:), z06(3,:), 'k-', 'linewidth',2);
            hold off
        end
        
        % Plot the circle we are trying to draw.
        hold on
        plot3(ox_history, oy_history, oz_history,'b.','markersize',10)
        hold off
    else
        % Once the animation has been set up, we don't need to reformat the
        % whole plot.  We just set the data to the correct new values for
        % the robot animation, the tip history, and the text showing the
        % elapsed time.
        set(hrobot,'xdata',points_to_plot(1,:),'ydata',points_to_plot(2,:),'zdata',points_to_plot(3,:))
        set(htip,'xdata',tip_history(1,1:i),'ydata',tip_history(2,1:i),'zdata',tip_history(3,1:i))
        set(htime,'string', (sprintf('t = %.2f s',t(i))));
        if showEndEffectorFrame
            set(hx,'xdata',x06(1,:),'ydata',x06(2,:),'zdata',x06(3,:))
            set(hy,'xdata',y06(1,:),'ydata',y06(2,:),'zdata',y06(3,:))
            set(hz,'xdata',z06(1,:),'ydata',z06(2,:),'zdata',z06(3,:))
        end
    end
    
    % Pause for a short duration so that the viewer can watch animation evolve over time.
    pause(GraphingTimeDelay)
    
end

%% FINISHED

% Set the view.
%view(-45,80)

disp('Done with the animation.')
