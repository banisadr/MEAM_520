function [points_to_plot, x06, y06, z06] = scara_robot_with_wrist_fk(a1, a2, d6, theta1, theta2, d3, theta4, theta5, theta6)

% Calculate the six A matrices based on DH parameters.
A1 = dh_kuchenbe(a1,    0,   0, theta1);
A2 = dh_kuchenbe(a2,   pi,   0, theta2);
A3 = dh_kuchenbe(0,     0,  d3,      0);
A4 = dh_kuchenbe(0, -pi/2,   0, theta4);
A5 = dh_kuchenbe(0,  pi/2,   0, theta5);
A6 = dh_kuchenbe(0,     0,  d6, theta6);

% Calculate the position of the origin for each frame.
o = [0 0 0 1]';
o0 = o;
o1 = A1*o0;
o2 = A1*A2*o0;
o3 = A1*A2*A3*o0;
o4 = A1*A2*A3*A4*o0;
o5 = A1*A2*A3*A4*A5*o0;
o6 = A1*A2*A3*A4*A5*A6*o0;

% Put the points together.
points_to_plot = [[0 0 -2 1]' o0 o1 o2 o3 o4 o5 o6];

% Save the full transformation in T06.
T06 = A1*A2*A3*A4*A5*A6;

% Length of coordinate frame vectors, in meters.
vlen = 0.3;

% Calculate the coordinates of the x, y, and z unit vectors of frame 6 in
% frame 0. Each of these vectors starts at the origin of frame 6 and ends
% at the distance vlen along the designated axis.  We calculate the
% location of the end by multiplying T06 into a scaled unit vector in the
% correct direction.
x06 = [o6 (T06 * [vlen 0 0 1]')];
y06 = [o6 (T06 * [0 vlen 0 1]')];
z06 = [o6 (T06 * [0 0 vlen 1]')];